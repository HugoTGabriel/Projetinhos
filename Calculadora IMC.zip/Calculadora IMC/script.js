function calcularIMC() {
    var altura = parseFloat(document.getElementById("altura").value);
    var peso = parseFloat(document.getElementById("peso").value);
    var resultado = document.getElementById("result");
  
    if (altura && peso) {
      var imc = peso / (altura * altura);
      resultado.innerHTML = "Seu IMC é: " + imc.toFixed(2);
    } else {
      resultado.innerHTML = "Por favor, insira a altura e o peso.";
    }
  }